from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time

driver_path = "C:\WebDriver"  # Update path here

service = Service(driver_path)
driver = webdriver.Chrome(service=service)

driver.get("https://practicetestautomation.com/practice-test-login/")

time.sleep(2)

driver.find_element(By.ID, "username").send_keys("student")
driver.find_element(By.ID, "password").send_keys("Password123")
driver.find_element(By.ID, "submit").click()

time.sleep(3)

if "Logged In Successfully" in driver.page_source:
    print("Test Case Passed: Successful login")
else:
    print("Test Case Failed: Login unsuccessful")

driver.quit()
